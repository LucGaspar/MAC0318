import numpy as np
import util
from sklearn.ensemble import RandomForestClassifier
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split

def train():
	data = np.load('npy/rule_120_160_3_data.npy') 
	labels = np.load('npy/rule_120_160_3_labels.npy')

	data_mnist = data
	label_mnist = labels

	new_data, new_labels = util.get_samples(data_mnist, 
                                    label_mnist, 
                                    size=8000)
	x_train, x_test, y_train, y_test = train_test_split(data_mnist,
                                                label_mnist,
                                                test_size = 0.30)
	clf = RandomForestClassifier(n_estimators=10,
                        criterion='entropy',
                        verbose=1)
	clf.fit(x_train, y_train.ravel())
	#predictions = clf.predict(x_test)
	#score = clf.score(x_test, y_test)
	#print(score)
	joblib.dump(clf, 'model.pkl')

train()