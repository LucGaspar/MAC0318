import numpy as np
import math

def get_samples(data, 
                labels, 
                size=3):
    idx_samples = np.random.randint(low=0, 
                                    high=len(labels),
                                    size=size)
    """
    Given the arrays data and labels, returns a tuple sample_data, sample_labels containing a number of elements specified in size parameter (default=3)
    sampled from data and labels. 
    The sampled dataset is a random process without replacement.
    
    :param data: data as vectors 
    :type data: np.array
    :param labels: labels of the dataset 
    :type labels: np.array
    :param size: number of elements in the sampled dataset
    :type size: int (default=3)
    """
    sample_data = np.array([data[idx] for idx in idx_samples])
    sample_labels = np.array([labels[idx] for idx in idx_samples])
    return sample_data, sample_labels