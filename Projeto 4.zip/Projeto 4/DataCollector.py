import os
import sys
import argparse
import numpy as np
from pathlib import Path
from Camera import Camera
from sklearn.externals import joblib
from sklearn.ensemble import RandomForestClassifier
from image_manipulation import binarize_image



path_current_dir = Path(os.getcwd())
one_level_up = path_current_dir.parents[0]
two_level_up = path_current_dir.parents[1]
parent_dir = os.path.join(str(two_level_up), "python_java")
sys.path.append(str(one_level_up))
sys.path.append(str(parent_dir))
import USBInterface # file located in ../../python_java/USBInterface.py

class DataCollector(object):

    def __init__(self, camera, brick):
        self.data_dict = {}
        self.brick = brick
        self.camera = camera
        self.clf = joblib.load("model.pickle")
        self.shape = 120 * 160 

    def predict(self, img):
        img = binarize_image(img)
        img = np.reshape(img, (1, self.shape))
        return self.clf.predict(img)

    def real_time(self):

        print("Ready...")
        while True:
            img = self.camera.take_picture()

            r = self.predict(img)[0]

            if (r == 0):
                self.brick.send('\x01')
            elif (r == 1):
                self.brick.send('\x04')
            elif (r == 2):
                self.brick.send('\x03')                    

def main():
    #train()
    camera = Camera(120, 160, 0)
    raise_exception = False
    try:
        brick = next(USBInterface.find_bricks(debug=False))
        brick.connect()
    except StopIteration:
        raise_exception = True
    assert raise_exception==0, "No NXT found..." 
    dc = DataCollector(camera, brick)
    dc.real_time()

if __name__=='__main__':
    main()
