import numpy as np
import util
from sklearn.ensemble import RandomForestClassifier
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split

def train():
	data = np.load('npy/rule_120_160_data.npy') 
	labels = np.load('npy/rule_120_160_labels.npy')

	data_mnist = data
	label_mnist = labels

	x_train, x_test, y_train, y_test = train_test_split(data_mnist,
                                                label_mnist,
                                                test_size=0)
	clf = RandomForestClassifier(n_estimators=30,
                        criterion='entropy',
                        verbose=1)
	clf.fit(x_train, y_train.ravel())
	joblib.dump(clf, 'model.pickle')